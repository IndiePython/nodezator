
def hello_world():
	print("hello world")

main_callable=hello_world
