def my_callable(]):
    "my callable"
    ...

main_callable = my_callable
