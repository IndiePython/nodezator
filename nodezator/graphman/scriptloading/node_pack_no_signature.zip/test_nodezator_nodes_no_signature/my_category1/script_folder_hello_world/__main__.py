
main_callable = lambda x : x+1
