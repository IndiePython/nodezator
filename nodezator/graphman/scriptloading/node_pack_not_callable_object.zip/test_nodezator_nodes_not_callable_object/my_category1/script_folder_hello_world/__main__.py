
class fake:
	a=1
	__name__="this"

main_callable = fake()
